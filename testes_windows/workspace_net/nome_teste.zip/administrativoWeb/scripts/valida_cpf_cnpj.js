﻿function replaceAll(string, token, newtoken) {
    while (string.indexOf(token) != -1) {
        string = string.replace(token, newtoken);
    }
    return string;
}

function LimpaCpfCnpj(doc) {
    doc = replaceAll(doc, '.', '');
    doc = replaceAll(doc, '-', '');
    doc = replaceAll(doc, '_', '');
    doc = replaceAll(doc, '/', '');

    return doc;
}

function validaCpf(src, args) {
    valor = LimpaCpfCnpj(args.Value);
    ret = true;

    // para não conflitar com a crítica de preenchimento.
    if (valor == '') {
        args.IsValid = true;
        return;
    }

    if ((isNaN(valor)) && (valor.length != 11))
        ret = false;

    if (valor == '00000000000' || valor == '11111111111' || valor == '22222222222' || valor == '33333333333' || valor == '44444444444' || valor == '55555555555' || valor == '66666666666' || valor == '77777777777' || valor == '88888888888' || valor == '99999999999')
        ret = false;

    Mult1 = 10;
    Mult2 = 11;
    dig1 = 0;
    dig2 = 0;

    valor = valor.toString();

    for (var i = 0; i <= 8; i++) {
        ind = valor.charAt(i);
        dig1 += ((parseFloat(ind)) * Mult1);
        Mult1--;
    }

    for (var i = 0; i <= 9; i++) {
        ind = valor.charAt(i);
        dig2 += ((parseFloat(ind)) * Mult2);
        Mult2--;
    }

    dig1 = (dig1 * 10) % 11;
    dig2 = (dig2 * 10) % 11;

    if (dig1 == 10)
        dig1 = 0;

    if (dig2 == 10)
        dig2 = 0;

    if (parseFloat(valor.charAt(9)) != dig1)
        ret = false;

    if (parseFloat(valor.charAt(10)) != dig2)
        ret = false;

    args.IsValid = ret;

}

function validaCnpj(src, args) {

    valor = LimpaCpfCnpj(args.Value);
    ret = true;

    // para não conflitar com a crítica de preenchimento.
    if (valor == '') {
        args.IsValid = true;
        return;
    }

    if (valor == '00000000000000')
        ret = false;

    if ((isNaN(valor)) && (valor.length != 14))
        ret = false

    Mult1 = "543298765432"
    Mult2 = "6543298765432"
    dig1 = 0
    dig2 = 0

    for (var i = 0; i <= 11; i++) {
        ind = valor.charAt(i)
        M = Mult1.charAt(i)
        dig1 += ((parseFloat(ind)) * (parseFloat(M)))
    }

    for (var i = 0; i <= 12; i++) {
        ind = valor.charAt(i)
        M = Mult2.charAt(i)
        dig2 += ((parseFloat(ind)) * (parseFloat(M)))
    }

    dig1 = (dig1 * 10) % 11
    dig2 = (dig2 * 10) % 11

    if (dig1 == 10)
        dig1 = 0

    if (dig2 == 10)
        dig2 = 0

    if (dig1 != (parseFloat(valor.charAt(12))))
        ret = false

    if (dig2 != (parseFloat(valor.charAt(13))))
        ret = false

    args.IsValid = ret
}
