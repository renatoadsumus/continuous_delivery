	
		/***
		* AUTO TAB - ao prencher o campo, automaticamente manda o foco para o pr�ximo!
		***/
		var isNN = (navigator.appName.indexOf("Netscape")!=-1);
		function autoTab(input,len, e) {
		var keyCode = (isNN) ? e.which : e.keyCode;
		var filter = (isNN) ? [0,8,9] : [0,8,9,16,17,18,37,38,39,40,46];
		if(input.value.length >= len && !containsElement(filter,keyCode)) {
		input.value = input.value.slice(0, len);
		input.form[(getIndex(input)+1) % input.form.length].focus();
		}

		function containsElement(arr, ele) {
		var found = false, index = 0;
		while(!found && index < arr.length)
		if(arr[index] == ele)
		found = true;
		else
		index++;
		return found;
		}

		function getIndex(input) {
		var index = -1, i = 0, found = false;
		while (i < input.form.length && index == -1)
		if (input.form[i] == input)index = i;
		else i++;
		return index;
		}
		return true;
		}
		//Fim da Fun��o AutoTab


		function PopDesistencia(lnk,pop,w,h,s) { 
		window.open(lnk,pop,'width='+w+',height='+h+',top=100,left=100,resizable=0,status=0,menubar=0,scrollbars='+s); 
		}

//Fun��es usadas pelo Custom Validator

function ValidaCampoBranco(vlCampo, nmErrCampo, msg) {

	if (isNull(vlCampo)){
		document.getElementById(nmErrCampo).style.display = 'block';
		if (msg != '')
			document.getElementById(nmErrCampo).innerHTML = msg;
		return false;
	}
	else {
		document.getElementById(nmErrCampo).style.display = 'none';
		return true;
	}

}

function ValidaExpressaoRegular(vlCampo, nmErrCampo, msg, regexpr) {

	if (vlCampo.search(regexpr) == -1){
		document.getElementById(nmErrCampo).style.display = 'block';
		if (msg != '')
			document.getElementById(nmErrCampo).innerHTML = msg;
		return false;
	}
	else {
		document.getElementById(nmErrCampo).style.display = 'none';
		return true;
	}

}

//Valida n�mero de cart�o smile
function ValidaSmile(par) {

	smile= par.toString();

	if (isNaN(smile) || smile.length !=9)
		return false
	else {		
		var LdSmile = smile.substring(0, 8);
		var LiDig = smile.substring(8, 9);
		var LiDigCalc = parseInt(LdSmile) % 7;
		if (LiDigCalc == LiDig)
			return true
		else
			return false;
	}

}

function ValidaCPF(valor) 
{

    if (valor == '')
      return false;

	if ((isNaN(valor)) && (valor.length != 11))
      return false;

	if (valor == '00000000000' || valor == '11111111111' || valor == '22222222222' || valor == '33333333333' || valor == '44444444444' || valor == '55555555555' || valor == '66666666666' || valor == '77777777777' || valor == '88888888888' || valor == '99999999999')
      return false;
	
	Mult1 = 10;   
	Mult2 = 11;
	dig1=0;
	dig2=0;
	
	valor= valor.toString();
	for(var i=0;i<=8;i++)
	{
	    ind=valor.charAt(i);
		dig1 += ((parseFloat(ind))* Mult1);
		Mult1--
	}
	
	for(var i=0;i<=9;i++)
	{
	    ind=valor.charAt(i);
		dig2 += ((parseFloat(ind))* Mult2);
		Mult2--
	}

	dig1 = (dig1 * 10) % 11;   
	dig2 = (dig2 * 10) % 11;   
	
	if (dig1 == 10)
      dig1 = 0;
      
	if(dig2 == 10)
      dig2 = 0;
	 
	if (parseFloat(valor.charAt(9)) != dig1)
		return false;   
	if (parseFloat(valor.charAt(10)) != dig2)
		return false;
		   
	return true  
}

function ValidaCNPJ(valor)
{
	if ((isNaN(valor)) && (valor.length != 14))
		return false
		
	Mult1 = "543298765432"
	Mult2 = "6543298765432"
	dig1=0
	dig2=0
		
	for(var i=0;i<=11;i++)   
	{
		ind=valor.charAt(i)
		M=Mult1.charAt(i)
		dig1 += ((parseFloat(ind)) *  (parseFloat(M)))
	}
	
	for( var i=0;i<=12;i++)   
	{
		ind=valor.charAt(i)
		M=Mult2.charAt(i)
		dig2 += ((parseFloat(ind)) *  (parseFloat(M)))
	}
		
	dig1 = (dig1 * 10) % 11
	dig2 = (dig2 * 10) % 11
	
	if (dig1 == 10)
		dig1 = 0
		
	if (dig2 == 10) 
		dig2 = 0

	if (dig1 != (parseFloat(valor.charAt(12))))
		return false
	
	if (dig2 != (parseFloat(valor.charAt(13))))
		return false
		
	return true
}


function isNull(str) 
{ 
	if (str==null) return true

	for (var intLoop = 0; intLoop < str.length; intLoop++)
		if (" " != str.charAt(intLoop))
			return false;            
	return true; 
}


function ValidaData(d,m,a)
{	
	if  (((isNull(d)) || (isNull(m)) || (isNull(a))) && ((!isNull(d)) && (!isNull(m)) && (!isNull(a)))) return false; 
	if ( (isNaN(d) && d != '') || (isNaN(m) && m != '') || (isNaN(a) && a != '') ) return false
	if ( (m<1 || m >12) && (m != '') ) return false
	if ( (d<1 || d >31) && (d != '') ) return false
	if ( (a<1900 || a>2078) && (a !='') ) return false
	if (d == 31)
	if( (m == 2) || (m == 4) || (m == 6) || (m == 9) || (m == 11)) return false
	if (m ==2)
	if( (parseInt(a)%4 != 0 && d ==29) || (d == 30) )return false
	return true
}

